package com.girish.starwars;


public class APIConstants {
    public static final String BASE_URL = "http://swapi.co/api";
}
